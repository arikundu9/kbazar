<?php
$dbserver="localhost";
$dbuser="root";
$dbpass="!SORI@sori20";
$dbname="kbazar";
$drop=1;

?>