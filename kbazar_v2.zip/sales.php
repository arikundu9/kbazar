<?php
include 'check_login.php';
$title="Sales :: KBazar.";
include 'header.php';
?>
<body>
	<?php	//include 'head.php';
			include 'nav.php'; 
			include 'msg.php';
	?>
	
	<main role="main" class="container-fluid mt-2">
		
		<div class="card main-container p-0 mb-2">
			<div class="card-header">
				<h5 class="card-title mb-0 text-center">Order List</h5>
			</div>
			<div class="card-body p-0 table-responsive">
				<table class="table table-bordered table-hover kb-table table-sm m-0">
				  <thead class="thead-light">
					<tr>
					  <th scope="col">
						<div class="custom-control custom-checkbox">
							<input type="checkbox" class="custom-control-input" id="sall"/>
							<label class="custom-control-label" for="sall">#</label>
						</div>
					  </th>
					  <th scope="col">Order ID</th>
					  <th scope="col">Product ID</th>
					  <th scope="col">Customer</th>
					  <th scope="col">Status</th>
					  <th scope="col">Date</th>
					</tr>
				  </thead>
				  <tbody>
					<tr>
					  <th scope="row">
						<div class="custom-control custom-checkbox">
							<input type="checkbox" class="custom-control-input" id="o_1"/>
							<label class="custom-control-label" for="o_1">1</label>
						</div>
						</th>
					  <td>13</td>
					  <td>320</td>
					  <td>Fname Lname</td>
					  <td>
						<button type="button" class="btn btn-primary btn-sm">Accept</button>
						<button type="button" class="btn btn-secondary btn-sm">Cancel</button>
						</td>
					  <td>00/00/0000</td>
					</tr>
					<tr>
					  <th scope="row">
						<div class="custom-control custom-checkbox">
							<input type="checkbox" class="custom-control-input" id="o_1"/>
							<label class="custom-control-label" for="o_1">1</label>
						</div>
						</th>
					  <td>13</td>
					  <td>320</td>
					  <td>Fname Lname</td>
					  <td>Pending</td>
					  <td>00/00/0000</td>
					</tr>
				  </tbody>
				</table>
			</div>
			<div class="card-footer d-flex align-content-center flex-wrap justify-content-between">
				<button type="button" class="btn btn-primary btn-sm">Accept Selected</button>
				<button type="button" class="btn btn-secondary btn-sm">Cancel Selected</button>
			</div>
		</div>
		
		<div class="row justify-content-center">
			<div class="col-12 col-sm-6 col-md-3 col-lg-3 col-xl-3 mb-2">
				<div class="card p-0 main-container">
					<div class="card-header">
						<h5 class="card-title mb-0 text-center">Stock Details</h5>
					</div>
					<div class="card-body">
						Total Amount: <h1>₹50,730/-</h1>
						Type of Products: <br><span class="h1">550 </span><span class="h3">type</span><br>
						Out of Stock: <br><span class="h1">11 </span><span class="h3">Products</span><br>
					</div>
					<div class="card-footer d-flex align-content-center flex-wrap justify-content-between">
						<button type="button" class="btn btn-primary btn-sm">Add Product</button>
					</div>
				</div>
			</div>
			<div class="col-12 col-sm-6 col-md-3 col-lg-3 col-xl-3 mb-2">
				<div class="card p-0 main-container">
					<div class="card-header">
						<h5 class="card-title mb-0 text-center">Daily Sale Graph</h5>
					</div>
					<div class="card-body">
						Day vs Sale
					</div>
					<div class="card-footer">
						Today's Sale: <span class="h2">₹650/-</span>
					</div>
				</div>
			</div>
			<div class="col-12 col-sm-6 col-md-3 col-lg-3 col-xl-3 mb-2">
				<div class="card p-0 main-container">
					<div class="card-header">
						<h4 class="card-title mb-0 text-center">KBazar Login</h4>
					</div>
					<div class="card-body">
						<form action="" method="post" enctype="multipart/form-data">
							<div class="input-group mb-2">
								<div class="input-group-prepend">
									<div class="input-group-text">ID: </div>
								</div>
								<input type="text" class="form-control" id="user" placeholder="Username">
							</div>
							<div class="input-group mb-4">
								<div class="input-group-prepend">
									<div class="input-group-text">Password: </div>
								</div>
								<input type="password" class="form-control" id="password" placeholder="Password">
							</div>
							<div class="custom-control custom-checkbox mr-sm-2 mb-3">
								<input type="checkbox" class="custom-control-input" id="customControlAutosizing">
								<label class="custom-control-label" for="customControlAutosizing">Remember this browser.</label>
							</div>
							<button type="button" class="btn btn-primary w-100" id="dwn">Login</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</main>
	
	<?php //include 'foot.php';?>
</body>
<?php include 'footer.php';?>
