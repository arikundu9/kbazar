<?php
$nav=[	
		'dashboard.php'=>['Dashboard',''],
		'products.php'=>['Products',''],
		'sales.php'=>['Sales',''],
		'customers.php'=>['Customers',''],
		'settings.php'=>['Settings','']
	];

$script=basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
$nav[$script][1]='active';
?>
<div class="container-fluid position-sticky mb-0 rbn">
	<div class="row">
		<div class="col p-0">
			<div class="xrb-left ml-auto"></div>
		</div>
		<div class="col-12 p-0">
			<nav class="navbar navbar-expand-md navbar-dark bg-dark py-0 px-0 sori_nav">
				<button class="navbar-toggler w-100 text-center btn-drop" type="button" data-toggle="collapse" 
						data-target="#navbarCollapse2" aria-controls="navbarCollapse2" 
						aria-expanded="false" aria-label="Toggle navigation">
					<span class="oi oi-collapse-down"></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarCollapse2">
					<ul class="navbar-nav mx-auto font-roboto-bold">
						<?php
						foreach($nav as $k=>$v){
							echo '
						<li class="nav-item text-center '.$v[1].'">
							<a class="nav-link" href="'.$k.'">'.@$v[0].'</a>
						</li>';
						}
						?>

					</ul>
					<a class="btn btn-light btn-sm mx-2" href="logout.php"><span class="oi oi-power-standby mr-1"></span>Logout</a>
				</div>
			</nav>
		</div>
		<div class="col p-0">
			<div class="xrb-right mr-auto"></div>
		</div>
	</div>
</div>