<?php
var_dump($_POST);
/*"<?php echo basename(__FILE__) ?>",*/
?>