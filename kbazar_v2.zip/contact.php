<?php
$title="Contacts - Susunia Pvt. Ltd.";
include 'header.php';
?>
<body>
	<?php include 'head.php'; ?>
	<?php include 'nav.php'; ?>
	
	<main role="main" class="container mt-3">
		<div class="main-container" align="center">
			<h2>Mobile No.  +919851081805 ,   +919734606012</h2>
			<h2>Email: contact@susunia.com</h2>
			<h2>Address: Kamalpur,Kamalpur,Chhatna,Bankura 722137 </h2>
		</div>
	</main>
	
	<?php include 'foot.php';?>
</body>
<?php include 'footer.php';?>
