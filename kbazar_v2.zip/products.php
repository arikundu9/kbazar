<?php
include 'check_login.php';
$title="Products :: KBazar.";
include 'header.php';
?>
<body>
	<?php	//include 'head.php';
			include 'nav.php'; 
			include 'msg.php';
	?>
	
<div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header p-2">
				<h5 class="modal-title" id="exampleModalLabel">Add New Product</h5>
				<button type="button" class="close p-1 mt-0 mr-0" data-dismiss="modal" aria-label="Close">
					<span aria-hidden="true">&times;</span>
				</button>
			</div>
			<div class="modal-body">
				<form name="addnew" method="post">
					<div class="form-group row">
						<label for="thumb" class="col-3 col-form-label"><b>Thumb:</b></label>
						<div class="col-3">
							<img class="card-img-top" src="./thumbs/default.jpg" alt="Card image cap">
							<div class="custom-file">
								<input type="file" class="custom-file-input" id="thumb1" name="thumb1"/>
								<label class="custom-file-label" for="thumb1">Thumb 1</label>
							</div>
						</div>
						<div class="col-3">
							<img class="card-img-top" src="./thumbs/default.jpg" alt="Card image cap">
							<div class="custom-file">
								<input type="file" class="custom-file-input" id="thumb2" name="thumb2"/>
								<label class="custom-file-label" for="thumb2">Thumb 2</label>
							</div>
						</div>
						<div class="col-3">
							<img class="card-img-top" src="./thumbs/default.jpg" alt="Card image cap">
							<div class="custom-file">
								<input type="file" class="custom-file-input" id="thumb3" name="thumb3"/>
								<label class="custom-file-label" for="thumb3">Thumb 3</label>
							</div>
						</div>
					</div>
					<div class="form-group row">
						<label for="name" class="col-2 col-form-label"><b>Name:</b></label>
						<div class="col-10">
							<input type="text" class="form-control" id="name" name="name"/>
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col-12 col-sm-6 col-md-6 col-lg-6">
						<label for="munit" class="col-form-label"><b>Measurement Unit:</b></label>
						<div class="input-group">
							<div class="input-group-prepend">
								<div class="input-group-text">Select </div>
							</div>
							<select class="custom-select" name="munit" id="munit">
								<option value="0">Unit</option>
								<optgroup label="Count">
									<option value="piece">Piece</option>
									<option value="packet">Packet</option>
									<option value="dibba">Dibba</option>
									<option value="bosta">Bosta</option>
								</optgroup>
								<optgroup label="Weight">
									<option value="kg">Kilogram</option>
									<option value="g">Gram</option>
								</optgroup>
								<optgroup label="Length">
									<option value="miter">Miter</option>
									<option value="feet">Feet</option>
									<option value="cm">cm</option>
									<option value="gauge">Gauge</option>
								</optgroup>
								<optgroup label="Volumn">
									<option value="liter">Liter</option>
								</optgroup>
								<option value=""></option>
							</select>
						</div>
						</div>
						<div class="form-group col-12 col-sm-6 col-md-6 col-lg-6">
							<label for="price" class="col-form-label"><b>Price Per <span id="pp">Unit</span>:</b></label>
							<div class="input-group">
								<div class="input-group-prepend">
									<div class="input-group-text">₹ </div>
								</div>
								<input type="number" min="0" class="form-control" id="price" name="price"/>
							</div>
						</div>
					</div>
					<div class="form-row">
						<div class="form-group col-12 col-sm-6 col-md-6 col-lg-6">
							<label for="stock" class="col-form-label"><b>Stock:</b></label>
							<div class="input-group">
								<input type="number" min="0" class="form-control" id="stock" name="stock"/>
								<div class="input-group-append">
									<div class="input-group-text" id="stock_unit">Unit.</div>
								</div>
							</div>
						</div>
						<div class="form-group col-12 col-sm-6 col-md-6 col-lg-6 mt-1">
							<div class="custom-control custom-checkbox">
								<input type="checkbox" checked="checked" class="custom-control-input" id="salebility" name="salebility"/>
								<label class="custom-control-label" for="salebility">Enable for sale</label>
							</div>
							<div class="custom-control custom-checkbox">
								<input type="checkbox" class="custom-control-input" id="refund" name="refund"/>
								<label class="custom-control-label" for="refund">Refundable Product ?</label>
							</div>
							<div class="custom-control custom-checkbox">
								<input type="checkbox" class="custom-control-input" id="replace" name="replace"/>
								<label class="custom-control-label" for="replace">Replaceable Product ?</label>
							</div>
						</div>
					</div>
					<div class="form-group row">
						<label for="minsale" class="col-12 col-sm-4 col-md-4 col-lg-3 col-form-label"><b>Minimum Sale:</b></label>
						<div class="col-12 col-sm-8 col-md-8 col-lg-9">
							<div class="input-group">
								<input type="number" value="1" min="1" class="form-control" id="minsale" name="minsale"/>
								<div class="input-group-append">
									<div class="input-group-text" id="stock_unit_min">Unit.</div>
								</div>
							</div>
						</div>
					</div>
					<div class="form-group">
						<label for="description" class="col-form-label"><b>Description:</b></label>
						<textarea class="form-control" id="description" name="description"></textarea>
					</div>
				</form>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary" id="addp">Save</button>
			</div>
		</div>
	</div>
</div>
	
	<main role="main" class="container-fluid mt-2">
		<div class="row justify-content-center" id="crow">
			<!--<div class="col-12 col-sm-6 col-md-3 col-lg-3 col-xl-3 mb-3">
				<div class="card kb-card">
					<div class="card-header kb-card-header kb-card-header-login">
						<h6 class="card-title mb-0 text-center">19 : Lifebuoy 100gm</h6>
					</div>
					<img class="card-img-top" src="./thumbs/default.jpg" alt="Card image cap">
						<ul class="list-group list-group-flush">
							<li class="list-group-item"><b>Price:</b> ₹20/-</li>
							<li class="list-group-item"><b>Stock:</b> 47 pieces</li>
							<li class="list-group-item"><b>Status:</b> Disabled</li>
						</ul>
					<div class="card-footer d-flex align-content-center flex-wrap justify-content-between">
						<button type="button" class="btn btn-primary btn-sm">Edit</button>
					</div>
				</div>
			</div>-->
			
		</div>
	</main>
	<div class="d-block" style="height:50px;"></div>
	<nav class="navbar navbar-expand-md fixed-bottom navbar-dark bg-dark xd-flex xalign-content-center xflex-wrap xjustify-content-between">
		<div class="navbar-collapse collapse" id="navbarCollapse" style="">
			<ul class="navbar-nav mr-auto">
				<li class="nav-item active">
					<a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="#">Link</a>
				</li>
				<li class="nav-item">
					<a class="nav-link disabled" href="#">Disabled</a>
				</li>
				<li class="nav-item dropup">
					<a class="nav-link dropdown-toggle" href="https://getbootstrap.com" id="dropdown10" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Filters</a>
					<div class="dropdown-menu" aria-labelledby="dropdown10">
						<a class="dropdown-item" href="#">No of Stock</a>
						<a class="dropdown-item" href="#">No of Sale</a>
						<a class="dropdown-item" href="#">Something else here</a>
					</div>
				</li>
			</ul>
			<form class="form-inline my-2 my-sm-0 mr-sm-2" method="get" action="login.php">
				<div class="input-group">
					<input class="form-control" id="pids" name="pid" type="text" placeholder="Enter Product ID" aria-label="Search"/>
					<button class="input-group-append btn btn-outline-success" id="pidsb" type="submit">Search</button>
				</div>
			</form>
		</div>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
			<span class="oi oi-collapse-up"></span>
		</button>
		<button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target=".bd-example-modal-lg">Add Product</button>
		<button type="button" class="btn btn-primary btn-sm" onclick="reload()">+-CHECK-+</button>
	</nav>
	<?php //include 'foot.php';?>
</body>
<?php include 'footer.php';?>
<script>
var Info=null;

$('#munit').on('change',function(){
	var u=$('#munit option:selected').text();
	$('#stock_unit').text(u);
	$('#stock_unit_min').text(u);
	$('#pp').text(u);
});

$('#addp').on('click',function(){
	dataa=new FormData();
	dataa.append('cmd','AddProduct');
	dataa.append('thumb1',$('#thumb1')[0].files[0] );
	dataa.append('thumb2',$('#thumb2')[0].files[0] );
	dataa.append('thumb3',$('#thumb3')[0].files[0] );
	dataa.append('name',$('#name').val());
	dataa.append('munit',$('#munit').val());
	dataa.append('price',$('#price').val());
	dataa.append('stock',$('#stock').val());
	dataa.append('salebility',$('#salebility').prop('checked'));
	dataa.append('refund',$('#refund').prop('checked'));
	dataa.append('replace',$('#replace').prop('checked'));
	dataa.append('minsale',$('#minsale').val());
	dataa.append('description',$('#description').val());
	$.ajax({
			method : 'POST',
			url: './ajax/products.ajax.php',
			data: dataa,
			cache: false,
			contentType: false,
			processData: false,
			success: function(msg){
				console.log(msg);
			}
	})
		.done(function(ret){
			response=$.parseJSON(ret);
			if(response.header.login==true){
				pid=response.body.pid
				$('#crow').append(
						'<div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 mb-3" id="item_'+pid+'">' + 
							'<div class="card kb-card">' + 
								'<div class="card-header kb-card-header kb-card-header-login">' + 
									'<h6 class="card-title mb-0 text-center">'+pid+' : '+dataa.get('name')+'</h6>' + 
								'</div>' + 
								'<img class="card-img-top kb-card-img-top" alt="Card image cap" id="thumb1_'+pid+'">' + 
								  '<ul class="list-group list-group-flush">' + 
									'<li class="kb list-group-item"><b>Price:</b> ₹'+dataa.get('price')+'/-</li>' + 
									'<li class="kb list-group-item"><b>Stock:</b> '+dataa.get('stock')+' '+dataa.get('munit')+'</li>' + 
									'<li class="kb list-group-item"><b>Status:</b> '+dataa.get('salebility')+'</li>' + 
								  '</ul>' + 
								'<div class="kb card-footer d-flex align-content-center flex-wrap justify-content-between">' + 
									'<button type="button" class="btn btn-primary btn-sm">Edit</button>' + 
								'</div>' + 
							'</div>' + 
						'</div>'
					);
				loadTHUMB1(pid);
			}
			else{
				window.location.replace('./index.php');
			}
		})
		.fail(function( jqxhr, textStatus, error ) {
			DATA=false;
			var err = textStatus + ", " + error;
			console.log( "Request Failed: " + err );
		});
	/*$.getJSON('./ajax/products.ajax.php',param={
		cmd:'AddProduct',
		name: $('#name').val(),
		munit: $('#munit').val(),
		price: $('#price').val(),
		stock: $('#stock').val(),
		salebility: $('#salebility').prop('checked'),
		refund: $('#refund').prop('checked'),
		replace: $('#replace').prop('checked'),
		minsale: $('#minsale').val(),
		description: $('#description').val()
		})
		.done(function(response){
			if(response.header.login==true){
				pid=response.body.pid
				$('#crow').append(
						'<div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 mb-3" id="item_'+pid+'">' + 
							'<div class="card kb-card">' + 
								'<div class="card-header kb-card-header kb-card-header-login">' + 
									'<h6 class="card-title mb-0 text-center">'+pid+' : '+param.name+'</h6>' + 
								'</div>' + 
								'<img class="card-img-top kb-card-img-top" src="" alt="Card image cap">' + 
								  '<ul class="list-group list-group-flush">' + 
									'<li class="kb list-group-item"><b>Price:</b> ₹'+param.price+'/-</li>' + 
									'<li class="kb list-group-item"><b>Stock:</b> '+param.stock+' '+Info.units[param.munit]+'</li>' + 
									'<li class="kb list-group-item"><b>Status:</b> '+param.salebility+'</li>' + 
								  '</ul>' + 
								'<div class="kb card-footer d-flex align-content-center flex-wrap justify-content-between">' + 
									'<button type="button" class="btn btn-primary btn-sm">Edit</button>' + 
								'</div>' + 
							'</div>' + 
						'</div>'
					);
			}
			else{
				window.location.replace('./index.php');
			}
		})
		.fail(function( jqxhr, textStatus, error ) {
			DATA=false;
			var err = textStatus + ", " + error;
			console.log( "Request Failed: " + err );
		});*/
});

$( document ).ready(function() {
	$.getJSON('./ajax/products.ajax.php',{
		cmd:'GetList',
		sort: 'id',
		order: 'asc',
		ipp: 12,
		page: 1
		})
		.done(function(response){
			if(response.header.login==true){
				Info=response;
				$.each(response.body,function(i,item){
					$('#crow').append(
						'<div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 mb-3" id="item_'+i+'">' + 
							'<div class="card kb-card">' + 
								'<div class="card-header kb-card-header kb-card-header-login">' + 
									'<h6 class="card-title mb-0 text-center">'+item.id+' : '+item.name+'</h6>' + 
								'</div>' + 
								'<img class="card-img-top kb-card-img-top" src="./thumbs/'+item.thumb1+'" alt="Card image cap">' + 
									'<ul class="list-group list-group-flush">' + 
										'<li class="kb list-group-item"><b>Price:</b> ₹'+item.price+'/-</li>' + 
										'<li class="kb list-group-item"><b>Stock:</b> '+item.stock+' '+Info.units[item.stock_unit]+'</li>' + 
										'<li class="kb list-group-item"><b>Status:</b> '+item.status+'</li>' + 
									'</ul>' + 
								'<div class="kb card-footer d-flex align-content-center flex-wrap justify-content-between">' + 
									'<button type="button" class="btn btn-primary btn-sm">Edit</button>' + 
								'</div>' + 
							'</div>' + 
						'</div>'
					);
				});
			}
			else{
				window.location.replace('./index.php');
			}
		})
		.fail(function( jqxhr, textStatus, error ) {
			DATA=false;
			var err = textStatus + ", " + error;
			console.log( "Request Failed: " + err );
		});
});

function reload() {
	//console.log(Info);
	$.getJSON('./ajax/products.ajax.php',{
		cmd:'GetList'
		})
		.done(function(response){
			if(response.header.login==true){
				Info=response;
				$.each(response.body,function(i,item){
					$('#crow').append(
						'<div class="col-12 col-sm-6 col-md-3 col-lg-2 col-xl-2 mb-3" id="item_'+i+'">' + 
							'<div class="card kb-card">' + 
								'<div class="card-header kb-card-header kb-card-header-login">' + 
									'<h6 class="card-title mb-0 text-center">'+item.id+' : '+item.name+'</h6>' + 
								'</div>' + 
								'<img class="card-img-top kb-card-img-top" src="'+item.thumb+'" alt="Card image cap">' + 
								  '<ul class="list-group list-group-flush">' + 
									'<li class="kb list-group-item"><b>Price:</b> ₹'+item.price+'/-</li>' + 
									'<li class="kb list-group-item"><b>Stock:</b> '+item.stock+' '+Info.units[item.stock_unit]+'</li>' + 
									'<li class="kb list-group-item"><b>Status:</b> '+item.status+'</li>' + 
								  '</ul>' + 
								'<div class="kb card-footer d-flex align-content-center flex-wrap justify-content-between">' + 
									'<button type="button" class="btn btn-primary btn-sm">Edit</button>' + 
								'</div>' + 
							'</div>' + 
						'</div>'
					);
				});
			}
			else{
				window.location.replace('./index.php');
			}
		})
		.fail(function( jqxhr, textStatus, error ) {
			DATA=false;
			var err = textStatus + ", " + error;
			console.log( "Request Failed: " + err );
		});
}

function loadTHUMB1(id) {
	input=$('#thumb1')[0];
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
			console.log(e);
            $('#thumb1_'+id+'').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}
//console.log(Info);
</script>
